from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Its a ai4i2020 packages",
    author="Udaykiran87",
    packages=find_packages(),
    license="MIT"
)